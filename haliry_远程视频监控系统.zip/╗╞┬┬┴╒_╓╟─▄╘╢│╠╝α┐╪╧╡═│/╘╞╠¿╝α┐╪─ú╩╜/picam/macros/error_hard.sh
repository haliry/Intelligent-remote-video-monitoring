#!/bin/bash
sudo shutdown -r now
